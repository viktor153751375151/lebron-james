let currentQuestion = 0;
const questions = [
  {
    question: "Who won the 2021 F1 World Championship?",
    correctAnswer: "Max Verstappen"
  },
  {
    question: "Which team does Charles Leclerc drive for?",
    correctAnswer: "Ferrari"
  },
  {
    question: "Who is known as 'The Iceman' in F1?",
    correctAnswer: "Kimi Räikkönen"
  }
];

function checkAnswer(selectedAnswer) {
  const correctAnswer = questions[currentQuestion].correctAnswer;
  const resultText = document.getElementById('result-text');
  if (selectedAnswer === correctAnswer) {
    resultText.textContent = "Correct!";
  } else {
    resultText.textContent = `Wrong! The correct answer was ${correctAnswer}.`;
  }
  document.getElementById('question-container').style.display = 'none';
  document.getElementById('result-container').style.display = 'block';
}

function nextQuestion() {
  currentQuestion++;
  if (currentQuestion < questions.length) {
    document.getElementById('question-text').textContent = questions[currentQuestion].question;
    document.getElementById('result-container').style.display = 'none';
    document.getElementById('question-container').style.display = 'block';
  } else {
    alert("You've completed the quiz!");
  }
}
